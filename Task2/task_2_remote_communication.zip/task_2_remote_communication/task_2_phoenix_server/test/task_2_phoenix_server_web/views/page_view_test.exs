defmodule Task2PhoenixServerWeb.PageViewTest do
  use Task2PhoenixServerWeb.ConnCase, async: true
end
