defmodule Swoosh.AttachmentContentError do
  defexception [:message]
end
