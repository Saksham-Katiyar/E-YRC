defmodule Task2PhoenixServer.Mailer do
  use Swoosh.Mailer, otp_app: :task_2_phoenix_server
end
