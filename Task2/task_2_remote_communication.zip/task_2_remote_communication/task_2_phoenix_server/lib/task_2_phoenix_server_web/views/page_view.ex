defmodule Task2PhoenixServerWeb.PageView do
  use Task2PhoenixServerWeb, :view
end
