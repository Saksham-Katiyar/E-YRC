defmodule Task4CPhoenixServerWeb.PageView do
  use Task4CPhoenixServerWeb, :view
end
