defmodule LineFollwerTest do
  use ExUnit.Case
  doctest LineFollwer

  test "greets the world" do
    assert LineFollwer.hello() == :world
  end
end
